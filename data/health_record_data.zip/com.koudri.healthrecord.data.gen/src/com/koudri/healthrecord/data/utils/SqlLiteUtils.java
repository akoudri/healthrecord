package com.koudri.healthrecord.data.utils;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EEnum;

public class SqlLiteUtils {
	
	public static String getAttSignature(EAttribute att)
	{
		StringBuilder sb = new StringBuilder();
		EDataType type = att.getEAttributeType();
		if (type instanceof EEnum || type.getName().equalsIgnoreCase("int"))
		{
			sb.append("int ");
		}
		else
		{
			sb.append("text ");
		}
		if (att.getLowerBound() == 1 && att.getUpperBound() == 1)
		{
			sb.append("not null");
		}
		sb.append(",");
		return sb.toString();
	}
	
	public static String getAttJavaType(EAttribute att)
	{
		EDataType type = att.getEAttributeType();
		if (type instanceof EEnum)
		{
			return type.getName();
		}
		else if (type.getName().equalsIgnoreCase("EInt"))
		{
			return "int";
		}
		else if (type.getName().equalsIgnoreCase("EBoolean"))
		{
			return "boolean";
		}
		else
		{
			return "String";
		}
	}

}
